path = 'C:/GitFolder/VMAT-QA-metrics/example/Pinnacle IMRT/Pinnacle_PatientData.RTP'
line,pointer = [],[]
with open(path, "r+") as f:
    
    line1 = f.readline()
    
    line.append(line1)
    while line1:
        
        pointer.append(f.tell())  #record the pointer loaction to help write
        
        line1 = f.readline()
        
        line.append(line1)
print(line[1])
SS = line[5]
K = SS.split('"')
K = [item for item in K if item != '' and item != ',']
KK = K[27:-2]

