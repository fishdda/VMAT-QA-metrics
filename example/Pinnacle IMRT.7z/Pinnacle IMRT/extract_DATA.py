class DATA_CLEAN:

    def __init__(self, DICOM_name, RTP_name):
        self.DICOM_name = DICOM_name
        self.RTP_name = RTP_name

    def extract_DICOM(self):

        import pydicom 
        import os

        plan_dcm = pydicom.read_file('Pinnacle_PatientData.dcm',force=True)
        print(dir(plan_dcm))

        


